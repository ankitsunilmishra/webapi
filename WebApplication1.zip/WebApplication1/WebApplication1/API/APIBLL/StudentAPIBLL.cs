﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ClassLibrary1.BLBase;
using ClassLibrary1.Model;
namespace WebApplication1.API.APIBLL
{
    internal sealed class StudentAPIBLL : StudentBLBase
    {
        internal new List<StudentModel> GetStudents()
        {
            return base.GetStudents();
        }
        internal new List<StudentModel> GetStudents(long studentID)
        {
            return base.GetStudents(studentID);
        }

        internal new int InsertStudent(StudentModel stu)
        {
            return base.InsertStudent(stu);
        }
        internal new int UpdateStudent(StudentModel studentModel)
        {
            return base.UpdateStudent(studentModel);
        }
        internal new int DeleteStudent(long studentID)
        {
            return base.DeleteStudent(studentID);
        }
    }
}