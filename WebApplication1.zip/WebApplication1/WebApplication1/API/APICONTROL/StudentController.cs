﻿using ClassLibrary1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApplication1.API.APIBLL;

namespace WebApplication1.API.APICONTROL
{
    public class StudentController : ApiController
    {
        private StudentAPIBLL objStudentBL;
        #region Response Method  
        /// <summary>  
        /// This method is used to fetch the Student Details  
        /// </summary>  
        /// <returns></returns>  
        [HttpGet, ActionName("GetStudentDetails")]
        public HttpResponseMessage GetStudentDetails()
        {
            objStudentBL = new StudentAPIBLL();
            HttpResponseMessage response;
            try
            {
                var detailsResponse = objStudentBL.GetStudents();
                if (detailsResponse != null)
                    response = Request.CreateResponse<List<StudentModel>>(HttpStatusCode.OK, detailsResponse);
                else
                    response = new HttpResponseMessage(HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                response = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
            return response;
        }

        [HttpGet, ActionName("GetStudentDetails")]
        public HttpResponseMessage GetStudentDetails(long studentID)
        {
            objStudentBL = new StudentAPIBLL();
            HttpResponseMessage response;
            try
            {
                var detailsResponse = objStudentBL.GetStudents(studentID);
                if (detailsResponse != null)
                    response = Request.CreateResponse<List<StudentModel>>(HttpStatusCode.OK, detailsResponse);
                else
                    response = new HttpResponseMessage(HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                response = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
            return response;
        }

        [HttpPost, ActionName("InsertStudent")]
        public HttpResponseMessage InsertStudent(StudentModel studentModel)
        {

            objStudentBL = new StudentAPIBLL();
            HttpResponseMessage response;
            try
            {
                var detailsResponse = objStudentBL.InsertStudent(studentModel);
                if (detailsResponse > 0)
                    response = Request.CreateResponse(HttpStatusCode.OK, "Record Inserted Successfully");
                else
                    response = new HttpResponseMessage(HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                response = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
            return response;
        }

        [HttpPut, ActionName("UpdateStudent")]
        public HttpResponseMessage UpdateStudent(StudentModel studentModel)
        {

            objStudentBL = new StudentAPIBLL();
            HttpResponseMessage response;
            try
            {
                var detailsResponse = objStudentBL.UpdateStudent(studentModel);
                if (detailsResponse > 0)
                    response = Request.CreateResponse(HttpStatusCode.OK, "Record Updated Successfully");
                else
                    response = new HttpResponseMessage(HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                response = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
            return response;
        }

        [HttpDelete, ActionName("DeleteStudent")]
        public HttpResponseMessage DeleteStudent(long studentID)
        {

            objStudentBL = new StudentAPIBLL();
            HttpResponseMessage response;
            try
            {
                var detailsResponse = objStudentBL.DeleteStudent(studentID);
                if (detailsResponse > 0)
                    response = Request.CreateResponse(HttpStatusCode.OK, "Record Deleted Successfully");
                else
                    response = new HttpResponseMessage(HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                response = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
            return response;
        }
        #endregion
    }
}
