﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ClassLibrary1.Model;
using System.Net.Http;
using System.Net.Http.Headers;

namespace ConsumeWebAPIClient.Services
{
    public  class StudentService
    {
        public APIResponse GetList()
        {
            APIResponse apinewResponse = new APIResponse(); 
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:56851/");
            client.DefaultRequestHeaders.Accept.Add( new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("api/User").Result;
            
            if (response.IsSuccessStatusCode)
            {
                apinewResponse.
                   Console.WriteLine("Success");
            }
        }
    }
}