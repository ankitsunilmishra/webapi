﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary1;
using ClassLibrary1.Model;
using ConsumeWebAPIClient.Services;
namespace ConsumeWebAPIClient.Forms_ASP
{
    public partial class Default : System.Web.UI.Page
    {
        private readonly StudentService obj = new StudentService();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            var studentList = obj.GetList();


        }
    }
}