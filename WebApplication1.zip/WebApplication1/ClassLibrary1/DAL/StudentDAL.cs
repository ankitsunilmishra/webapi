﻿using System;
using System.Data;
using System.Data.Common;
using System.Collections.Generic;
using Microsoft.Practices.EnterpriseLibrary.Data;
using ClassLibrary1.Model;

namespace ClassLibrary1.DAL
{
    public class StudentDAL
    {
        Database db = null;
        public StudentDAL()
        {
            DatabaseProviderFactory factory = new DatabaseProviderFactory();
            db = factory.Create("VisionConnection");

        }

        public List<StudentModel> GetStudents()
        {
            var returnManager = new List<StudentModel>();
            using (DbConnection conn = db.CreateConnection())
            {
                try
                {
                    DbCommand command = db.GetStoredProcCommand("USP_GET_ALL_RECORDS");
                    db.AddInParameter(command, "@LIST_CASE", DbType.String, "Select");

                    conn.Open();
                    IDataReader reader = db.ExecuteReader(command);

                    while (reader.Read())
                    {
                        var studentModel = new StudentModel()
                        {
                            ID = reader.GetInt64(0),
                            Age = reader.IsDBNull(3) ? null : (long?)reader.GetInt64(3),
                            StudentName = reader.IsDBNull(1) ? null : reader.GetString(1),
                            EmailId = reader.IsDBNull(2) ? null : reader.GetString(2)

                        };
                        returnManager.Add(studentModel);
                    }

                    reader.Close();
                }
                finally
                {
                    conn.Close();
                }
            }
            return returnManager;
        }

        public List<StudentModel> GetStudents(long studentID)
        {
            var returnManager = new List<StudentModel>();
            using (DbConnection conn = db.CreateConnection())
            {
                try
                {
                    DbCommand command = db.GetStoredProcCommand("USP_GET_ALL_RECORDS");
                    db.AddInParameter(command, "@LIST_CASE", DbType.Int64, studentID);

                    conn.Open();
                    IDataReader reader = db.ExecuteReader(command);

                    while (reader.Read())
                    {
                        var studentModel = new StudentModel()
                        {
                            ID = reader.GetInt64(0),
                            Age = reader.IsDBNull(3) ? null : (long?)reader.GetInt64(3),
                            StudentName = reader.IsDBNull(1) ? null : reader.GetString(1),
                            EmailId = reader.IsDBNull(2) ? null : reader.GetString(2)

                        };
                        returnManager.Add(studentModel);
                    }

                    reader.Close();
                }
                finally
                {
                    conn.Close();
                }
            }
            return returnManager;
        }

        public int InsertStudent(StudentModel studentModel)
        {
            var returnManager = 0;
            using (DbConnection conn = db.CreateConnection())
            {
                try
                {
                    DbCommand command = db.GetStoredProcCommand("USP_I_INSERT_STUDENT");
                    db.AddInParameter(command, "@StudentName", DbType.String, studentModel.StudentName);
                    db.AddInParameter(command, "@StudentEmailId", DbType.String, studentModel.EmailId);
                    db.AddInParameter(command, "@Age", DbType.Int64, studentModel.Age);
                    conn.Open();
                    returnManager = db.ExecuteNonQuery(command);
                }
                finally
                {
                    conn.Close();
                }
            }
            return returnManager;
        }

        public int UpdateStudent(StudentModel studentModel)
        {
            var returnManager = 0;
            using (DbConnection conn = db.CreateConnection())
            {
                try
                {
                    DbCommand command = db.GetStoredProcCommand("USP_U_UPDATE_STUDENT");
                    db.AddInParameter(command, "@Id", DbType.Int64, studentModel.ID);
                    db.AddInParameter(command, "@StudentName", DbType.String, studentModel.StudentName);
                    db.AddInParameter(command, "@StudentEmailId", DbType.String, studentModel.EmailId);
                    db.AddInParameter(command, "@Age", DbType.Int64, studentModel.Age);
                    conn.Open();
                    returnManager = db.ExecuteNonQuery(command);
                }
                finally
                {
                    conn.Close();
                }
            }
            return returnManager;
        }

        public int DeleteStudent(long studentID)
        {
            var returnManager = 0;
            using (DbConnection conn = db.CreateConnection())
            {
                try
                {
                    DbCommand command = db.GetStoredProcCommand("USP_D_DELETE_STUDENT");
                    db.AddInParameter(command, "@Id", DbType.Int64, studentID);
                    conn.Open();
                    returnManager = db.ExecuteNonQuery(command);
                }
                finally
                {
                    conn.Close();
                }
            }
            return returnManager;
        }
    }
}
