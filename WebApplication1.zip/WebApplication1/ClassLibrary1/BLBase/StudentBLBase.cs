﻿using ClassLibrary1.DAL;
using ClassLibrary1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.BLBase
{

    public abstract class StudentBLBase
    {
        #region Product table Operations
        /// <summary>
        /// This function to be used to get all Products from database.
        /// </summary>
        /// <returns>Student Model  type List object</returns>
        protected List<StudentModel> GetStudents()
        {
            List<StudentModel> result = null;
            try
            {
                result = new StudentDAL().GetStudents();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        protected List<StudentModel> GetStudents(long studentID)
        {
            List<StudentModel> result = null;
            try
            {
                result = new StudentDAL().GetStudents(studentID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;

        }

        protected int InsertStudent(StudentModel student)
        {
            int result = 0;
            try
            {
                result = new StudentDAL().InsertStudent(student);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        protected int UpdateStudent(StudentModel student)
        {
            int result = 0;
            try
            {
                result = new StudentDAL().UpdateStudent(student);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        protected int DeleteStudent(long studentID)
        {
            int result = 0;
            try
            {
                result = new StudentDAL().DeleteStudent(studentID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
        #endregion
    }
}
