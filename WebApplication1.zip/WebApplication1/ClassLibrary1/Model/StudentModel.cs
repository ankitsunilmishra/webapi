﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Model
{
    public class StudentModel
    {
        public long ID { get; set; }
        public string StudentName { get; set; }

        public long? Age { get; set; }

        public string EmailId { get; set; }
    }
}
